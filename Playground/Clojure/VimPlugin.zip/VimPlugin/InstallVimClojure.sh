#!/bin/sh
sudo rsync -avz . /usr/share/vim/vim72/
